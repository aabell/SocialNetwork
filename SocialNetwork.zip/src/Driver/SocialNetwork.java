package Driver;
import java.util.*;
public class SocialNetwork 
{
     public  ArrayList<Person> users;
	
public SocialNetwork()
{
	users=new ArrayList<Person>();
}

public static Person friendRecomendation(Person p)
	{
		//ArrayList<Person> all = new ArrayList<Person>();
		ArrayList<Person> FriendsOfFriends = new ArrayList<Person>(p.getFriendsOfFriends());
		ArrayList<String> FriendsOfFriends2 = new ArrayList<String>();
		
		for (Person friend : FriendsOfFriends) {
			FriendsOfFriends2.add(friend.getName());
			
		}
			Collections.sort(FriendsOfFriends2);
		
		
			/*ArrayList<Person> Friendsofp = new ArrayList<Person>(p.getFriendsOfFriends());
			ArrayList<String> FriendsOfp2 = new ArrayList<String>();
			for (Person friend : Friendsofp) {
				FriendsOfp2.add(friend.getName());
			}*/
		    
			for(String ccb:FriendsOfFriends2){
		    	if(!FriendsOfFriends2.contains(ccb));
		    	return new Person(ccb);
		    }
		    
			
			return null;
		    }
public String toString(){
	String str ="";
	
	for(Person p : users){
		str+=p.getName()+" is friends with ";
		
		for(Person fOfp : p.getFriendList()){
			
			str+= fOfp.getName() + ", ";
			
		}
		
		
		
		int idx = str.lastIndexOf(",");
		if (idx>=0) {
		   str = str.substring(0,idx) +"\n";
		}
		
}
	
	return str;
}
}
