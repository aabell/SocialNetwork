package Driver;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSimple {

	@Test
	public void test() {
		Person p = new Person("");
		Person p1 = new Person(p);
		Person p2 = new Person("");
		
		p.addFriend(p1);
		p.addFriend(p2);
		
		assertEquals(p.getFriendList().size(), 2);
	}

}
