package Driver;

public class Driver {
	
	// Most popular recent baby names for each letter of the alphabet.
	public final static String[] names = 
		{"Ava", "Benjamin", "Charlotte", "Daniel", "Emma", 
				"Faith", "Grace", "Harper", "Isabella", "Jacob", "Kaylee", 
				"Liam", "Mason", "Noah", "Olivia", "Peyton", "Quinn", "Ryan", 
				"Sophia", "Taylor", "Uriel", "Victoria", "William", "Xavier", 
				"Yaretzi", "Zoey"};
	
	
	public static void main(String[] args) {
		
		// Creating an array of 26 people and a new social network.
		Person[] people = new Person[26];
		for (int i = 0; i < names.length; i++) {
			people[i] = new Person(names[i]);
		}
		SocialNetwork net = new SocialNetwork();
		
		// Adding users.
		for (int i = 0; i < 12; i++) {
			net.users.add(people[i]);
		}		
		
		// Adding friendships.
		for (int i = 0, j = 1; i < 500; i += 5, j += 7) {
			Person friend1 = people[i%12];
			Person friend2 = people[j%12];
			if (net.users.contains(friend1) && net.users.contains(friend2)) {
				net.users.get(net.users.indexOf(friend1)).addFriend(
						net.users.get(net.users.indexOf(friend2)));;
			}
		}
		for (int i = 0, j = 1; i < 500; i += 2, j += 3) {
			Person friend1 = people[i%12];
			Person friend2 = people[j%12];
			if (net.users.contains(friend1) && net.users.contains(friend2)) {
				net.users.get(net.users.indexOf(friend1)).addFriend(
						net.users.get(net.users.indexOf(friend2)));;
			}
		}
		
		
		// Printing tests
		
		System.out.println(net);
		
		Person testPerson = net.users.get(4);
		System.out.println("Recommendation for " + testPerson + ": "
				+ net.friendRecomendation(testPerson));
		
		testPerson.addFriend(net.friendRecomendation(testPerson));
		
		System.out.println(testPerson + "'s updated friend list:\n" 
				+ testPerson.getFriendList());
		
//		testPerson.sortFriends();
		
//		System.out.println(testPerson + "'s sorted friend list:\n" 
//				+ testPerson.getFriendList());
		
		testPerson.deleteFriend(testPerson.getFriendList().get(1));
		
		System.out.println(testPerson + 
				"'s new friend list:\n" 
				+ testPerson.getFriendList());
		
	}

}
