package Driver;

import java.util.ArrayList;
import java.util.Collection;
//import java.util.HashSet;
//import java.util.Set;
import java.util.*;
public class Person {
	private String name;
	private static int id =0;//1//0
	//private ArrayList<String>feriend=new ArrayList<String>();
	
	private ArrayList<Person> friendList = new ArrayList<Person>();
	public Person()
	{
		id+=1;
		//id++;
		this.name="Anon"+id;
		//+ id;//+ ++id
		//this.name="Anon1"+ ++id;
	}
	public Person(String name){
		this.name=name;
	}
	public Person(Person P)
	{
		
		
		this.name=P.name;
		
		this.friendList= new ArrayList<Person>(P.friendList);
	}
	public String getName(){
		return name;
	}

	public void setName(String name){
		this.name=name;
	}
	public void addFriend(Person p){
		
		if (friendList.contains(p)) 
		{
			
		} else {
			//feriend.add(p.name);
			friendList.add(p);
			//(p.feriend).add(this.name);
			p.friendList.add(this);
		
		
		}}
	
		public boolean deleteFriend(Person p){
			if(friendList.contains(p)||p.friendList.contains(this)){
				friendList.remove(p);
				p.friendList.remove(this);
				return true;
			}
			else{
				return false;
		}
		}	
		
			   
public boolean deleteFriend(String frenemyName)
{
	boolean y=false;
	for (Person p : friendList ) 
	{
	    if(p.getName().equals(frenemyName)){
		    p.friendList.remove(this);
		    this.friendList.remove(p);
		   y=true;
		    break;
	    }
	}
	    
	   return y;
		    
		 
		    
		    
	
	
}
public ArrayList<Person> getFriendList(){
	ArrayList<Person> shallow = new ArrayList<Person>(this.friendList);
	return shallow;
}
public ArrayList<Person> getFriendsOfFriends(){
	ArrayList<Person> friendList1 = new ArrayList<Person>();

for(Person p:friendList)
	for(Person q:p.friendList)
	if(q!=this && this.friendList.contains(q)){
		friendList1.add(q);
	}
		
	


return friendList1;

}



public String toString()
{
	return this.name;
}
public static int numberOfMutualFriends(Person p, Person q)
{
	
 Set<Person>res = new HashSet<>(p.friendList);
 res.retainAll(q.friendList);
 return res.size();

}
}
